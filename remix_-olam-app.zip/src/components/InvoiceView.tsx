import React, { useState, useEffect } from 'react';
import { Order, CartItem } from '../types';
import { 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Receipt, 
  CreditCard, 
  Ban, 
  Edit3, 
  ShieldAlert, 
  Check, 
  ChefHat, 
  Truck, 
  AlertTriangle 
} from 'lucide-react';
import { motion } from 'motion/react';

interface InvoiceViewProps {
  orders: Order[];
  onCancelOrder: (orderId: string) => void;
  onModifyOrder: (order: Order) => void;
  onConfirmOrderReceipt?: (
    orderId: string,
    signatureSvg: string,
    receivedCorrectly: boolean,
    recipientComments: string
  ) => void;
}

export default function InvoiceView({ 
  orders, 
  onCancelOrder, 
  onModifyOrder,
  onConfirmOrderReceipt 
}: InvoiceViewProps) {
  const [timeLeftList, setTimeLeftList] = useState<{ [orderId: string]: string }>({});
  const [canModifyList, setCanModifyList] = useState<{ [orderId: string]: boolean }>({});

  // States to represent customer sign pad
  const [signatureMode, setSignatureMode] = useState<'draw' | 'type'>('type');
  const [typedName, setTypedName] = useState<{ [orderId: string]: string }>({});
  const [receivedCheck, setReceivedCheck] = useState<{ [orderId: string]: boolean }>({});
  const [comments, setComments] = useState<{ [orderId: string]: string }>({});

  useEffect(() => {
    const updateCountdowns = () => {
      const now = new Date().getTime();
      const updatedTimes: { [orderId: string]: string } = {};
      const updatedCanModify: { [orderId: string]: boolean } = {};

      orders.forEach((order) => {
        const orderTime = new Date(order.createdAt).getTime();
        const thirtyMinutes = 30 * 60 * 1000;
        const limitTime = orderTime + thirtyMinutes;
        const diff = limitTime - now;

        if (diff > 0 && order.status === 'Pendiente') {
          const minutes = Math.floor((diff / 1000 / 60) % 60);
          const seconds = Math.floor((diff / 1000) % 60);
          updatedTimes[order.id] = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
          updatedCanModify[order.id] = true;
        } else {
          updatedTimes[order.id] = '00:00';
          updatedCanModify[order.id] = false;
        }
      });

      setTimeLeftList(updatedTimes);
      setCanModifyList(updatedCanModify);
    };

    updateCountdowns();
    const interval = setInterval(updateCountdowns, 1000);
    return () => clearInterval(interval);
  }, [orders]);

  const formattedPrice = (price: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getStatusBadgeColor = (status: string) => {
    if (status === 'Pendiente') return 'bg-amber-500/10 border-amber-500/30 text-amber-500';
    if (status === 'En Preparación') return 'bg-indigo-500/10 border-indigo-550/30 text-indigo-400';
    if (status === 'Enviado') return 'bg-sky-500/10 border-sky-505/30 text-sky-400';
    if (status === 'Entregado') return 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
    return 'bg-rose-500/10 border-rose-500/30 text-rose-450';
  };

  // Simple paint helper functions using 2D context canvas
  const startPaint = (orderId: string, e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = document.getElementById(`signature-canvas-${orderId}`) as HTMLCanvasElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    if (canvas.width !== canvas.offsetWidth || canvas.height !== canvas.offsetHeight) {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      ctx.strokeStyle = '#f59e0b'; // Amber yellow
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';
    }

    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
    (canvas as any).drawing = true;
    
    if (!typedName[orderId]) {
      setTypedName({ ...typedName, [orderId]: 'Firma Manual' });
    }
  };

  const drawPaint = (orderId: string, e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = document.getElementById(`signature-canvas-${orderId}`) as HTMLCanvasElement;
    if (!canvas || !(canvas as any).drawing) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const startPaintTouch = (orderId: string, e: React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = document.getElementById(`signature-canvas-${orderId}`) as HTMLCanvasElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    if (canvas.width !== canvas.offsetWidth || canvas.height !== canvas.offsetHeight) {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';
    }

    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    ctx.beginPath();
    ctx.moveTo(touch.clientX - rect.left, touch.clientY - rect.top);
    (canvas as any).drawing = true;

    if (!typedName[orderId]) {
      setTypedName({ ...typedName, [orderId]: 'Firma Manual' });
    }
  };

  const drawPaintTouch = (orderId: string, e: React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = document.getElementById(`signature-canvas-${orderId}`) as HTMLCanvasElement;
    if (!canvas || !(canvas as any).drawing) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    ctx.lineTo(touch.clientX - rect.left, touch.clientY - rect.top);
    ctx.stroke();
  };

  const stopPaint = (orderId: string) => {
    const canvas = document.getElementById(`signature-canvas-${orderId}`) as HTMLCanvasElement;
    if (canvas) {
      (canvas as any).drawing = false;
    }
  };

  const clearCanvas = (orderId: string) => {
    const canvas = document.getElementById(`signature-canvas-${orderId}`) as HTMLCanvasElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    const updated = { ...typedName };
    delete updated[orderId];
    setTypedName(updated);
  };

  const getCanvasImage = (orderId: string) => {
    const canvas = document.getElementById(`signature-canvas-${orderId}`) as HTMLCanvasElement;
    if (!canvas) return '';
    try {
      return canvas.toDataURL('image/png');
    } catch {
      return 'Firma Manuscrita';
    }
  };

  const isCanvasDrawn = (orderId: string) => {
    return !!typedName[orderId];
  };

  return (
    <div id="invoice-view-container" className="max-w-3xl mx-auto p-4 sm:p-6 lg:p-8 font-sans space-y-8">
      <div>
        <p className="text-[10px] uppercase tracking-[0.2em] text-[#ff8c38] font-bold">RF 6 & 8 & 12</p>
        <h2 className="text-xl font-light tracking-tight text-white uppercase leading-none mt-1">Mis Facturas y Entregas</h2>
        <p className="text-xs text-white/50 mt-1">
          Consulta tus solicitudes electrónicas y monitorea el estado en vivo. Si tu orden se encuentra "Enviado", por favor certifícalo y fírmalo para cerrar la entrega (RF12).
        </p>
      </div>

      {orders.length === 0 ? (
        <div id="no-invoices-state" className="p-8 text-center bg-[#0F0F0F] border border-white/10 rounded-sm space-y-2">
          <Receipt className="h-10 w-10 text-white/20 mx-auto stroke-[1.5]" />
          <p className="text-sm font-semibold text-white">Aún no has realizado pedidos</p>
          <p className="text-xs text-white/40">Regresa al menú e inicia tu primer orden de comida premium.</p>
        </div>
      ) : (
        <div id="historical-invoices-stack" className="space-y-6">
          {orders.map((order) => {
            const countdown = timeLeftList[order.id] || '30:00';
            const canModify = canModifyList[order.id];

            return (
              <div
                key={order.id}
                id={`invoice-card-${order.id}`}
                className="bg-[#0F0F0F] border border-white/10 rounded-sm overflow-hidden shadow-xl"
              >
                {/* Invoice Header details */}
                <div className="p-4 sm:p-5 border-b border-white/10 bg-white/5 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center space-x-2.5">
                    <div className="p-2 bg-black border border-white/10 rounded-sm text-amber-500">
                      <Receipt className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-[10px] text-white/40 uppercase tracking-widest font-semibold">Factura electrónica</p>
                      <h4 className="text-sm font-bold text-white tracking-tight">{order.invoiceId}</h4>
                    </div>
                  </div>

                  {/* Order state badge */}
                  <div className="flex items-center space-x-2">
                    <span className={`px-2.5 py-0.5 rounded-sm border text-[10px] font-bold tracking-wide uppercase ${getStatusBadgeColor(order.status)}`}>
                      {order.status}
                    </span>
                  </div>
                </div>

                {/* Main Content Layout */}
                <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-5 border-b border-white/10 text-xs text-white">
                  {/* Detailed Items list */}
                  <div className="col-span-1 md:col-span-2 space-y-3">
                    <p className="text-[10px] uppercase tracking-widest text-white/40 font-semibold pb-1 border-b border-white/10">
                      Platos Ordenados
                    </p>
                    <div className="space-y-2.5">
                      {order.items.map((item) => (
                        <div key={item.cartItemId} className="flex gap-2 p-2 bg-white/5 rounded-sm border border-white/5">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="h-10 w-10 object-cover rounded-sm shrink-0 border border-white/5"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between font-bold text-white">
                              <p className="truncate pr-2">{item.product.name} (x{item.quantity})</p>
                              <span className="font-mono">{formattedPrice(item.totalPrice)}</span>
                            </div>

                            {/* Customize labels for recipe changes */}
                            {(item.removedIngredients.length > 0 || item.addedIngredients.length > 0) && (
                              <div className="mt-1 flex flex-wrap gap-1">
                                {item.removedIngredients.map((r) => (
                                  <span key={r} className="text-[8.5px] bg-rose-500/10 text-rose-400 px-1 py-0.2 rounded border border-rose-500/15">
                                    Sin {r}
                                  </span>
                                ))}
                                {item.addedIngredients.map((a) => (
                                  <span key={a.name} className="text-[8.5px] bg-emerald-500/10 text-emerald-450 px-1 py-0.2 rounded border border-emerald-500/15">
                                    + {a.name}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Summary Logistics, payment and ETA details */}
                  <div className="space-y-4 bg-white/5 p-3.5 rounded-sm border border-white/5">
                    <p className="text-[10px] uppercase tracking-widest text-white/40 font-semibold pb-1 border-b border-white/10">
                      Detalles de Entrega
                    </p>

                    <div className="space-y-3">
                      <div className="flex items-start gap-1.5 text-[11px]">
                        <MapPin className="h-4 w-4 text-white/30 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-slate-300">Dirección</p>
                          <p className="text-white/60 text-[10px]">{order.customerAddress}</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-1.5 text-[11px]">
                        <CreditCard className="h-4 w-4 text-white/30 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-slate-300">Medio de Pago</p>
                          <p className="text-white/50 text-[10px] font-mono">{order.paymentMethod}</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-1.5 text-[11px]">
                        <Clock className="h-4 w-4 text-white/30 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-slate-300">Tiempo de Llegada</p>
                          <p className="text-amber-500 text-[10px] font-semi-bold">{order.estimatedArrivalMinutes} min aprox.</p>
                        </div>
                      </div>
                    </div>

                    {/* RF11: Responsables de preparacion y envio del restaurante */}
                    {(order.preparerName || order.assignedDriver) && (
                      <div className="p-2.5 bg-black/40 border border-white/10 rounded-sm space-y-1.5 text-[10.5px]">
                        <p className="text-[8.5px] text-amber-500 font-bold uppercase tracking-wider leading-none">Asignados del Servicio (RF11)</p>
                        {order.preparerName && (
                          <div className="text-white/80">
                            👨‍🍳 Preparador: <strong className="text-white font-medium">{order.preparerName}</strong>
                          </div>
                        )}
                        {order.assignedDriver && (
                          <div className="text-white/80">
                            🛵 Domiciliario: <strong className="text-white font-medium">{order.assignedDriver.fullName}</strong> ({order.assignedDriver.vehicleType === 'Bicicleta' ? 'Bici' : order.assignedDriver.plate})
                          </div>
                        )}
                      </div>
                    )}

                    <div className="pt-2 border-t border-white/10 flex justify-between items-baseline leading-none">
                      <p className="text-[10px] text-white/30 uppercase tracking-wider">Total Facturado</p>
                      <p className="text-base font-bold text-amber-500 font-mono">{formattedPrice(order.total)}</p>
                    </div>
                  </div>
                </div>

                {/* RF12: Expandable Reception sign box when order is in Enviado state */}
                {order.status === 'Enviado' && onConfirmOrderReceipt && (
                  <div className="border-t border-dashed border-white/20 p-5 bg-[#0A0A0A] space-y-4 font-sans text-white">
                    <div className="space-y-1">
                      <p className="text-[10px] uppercase tracking-[0.15em] text-[#ff8c38] font-bold">RF12: Confirmación y Firma de Recepción de Pedidos</p>
                      <h4 className="text-sm font-light uppercase tracking-tight">Confirmar Recibido de Compra</h4>
                      <p className="text-xs text-white/50 leading-normal">
                        Para registrar exitosamente tu pedido como "Entregado" y dejar constancia formal, revisa que todo haya llegado correctamente y firma en el siguiente recuadro.
                      </p>
                    </div>

                    <div className="space-y-3.5 text-xs text-white/80">
                      {/* Received checklist */}
                      <label id={`received-checkbox-container-${order.id}`} className="flex items-start gap-2.5 cursor-pointer select-none">
                        <input
                          id={`received-checkbox-${order.id}`}
                          type="checkbox"
                          checked={receivedCheck[order.id] !== false}
                          onChange={(e) => setReceivedCheck({ ...receivedCheck, [order.id]: e.target.checked })}
                          className="h-4 w-4 rounded-sm border border-white/10 bg-black text-amber-500 accent-amber-500 focus:ring-0 mt-0.5"
                        />
                        <div>
                          <span className="font-bold text-white block">✔ He verificado el producto y está correcto</span>
                          <span className="text-[10px] text-white/40">Confirmo que el plato coincide con la receta personalizada que solicité.</span>
                        </div>
                      </label>

                      {/* Client delivery comments */}
                      <div className="space-y-1">
                        <label className="block text-[10px] text-white/40 uppercase font-mono">Observaciones / Calificación del domicilio:</label>
                        <input
                          id={`input-comments-${order.id}`}
                          type="text"
                          value={comments[order.id] || ''}
                          onChange={(e) => setComments({ ...comments, [order.id]: e.target.value })}
                          placeholder="Ej: Llegó rápido y en excelente temperatura."
                          className="w-full bg-black border border-white/10 text-white p-2 text-xs rounded-sm focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      {/* Signature block methods selector */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] text-white/40 uppercase font-mono">Firma Digital del Cliente:</label>
                          <div className="flex gap-2">
                            <button
                              id={`method-type-btn-${order.id}`}
                              type="button"
                              onClick={() => setSignatureMode('type')}
                              className={`px-2 py-0.5 text-[9px] rounded-sm border cursor-pointer transition-all ${signatureMode === 'type' ? 'bg-amber-500 text-black border-amber-600 font-bold' : 'bg-black border-white/10 text-white/50'}`}
                            >
                              Escribir Firma
                            </button>
                            <button
                              id={`method-draw-btn-${order.id}`}
                              type="button"
                              onClick={() => setSignatureMode('draw')}
                              className={`px-2 py-0.5 text-[9px] rounded-sm border cursor-pointer transition-all ${signatureMode === 'draw' ? 'bg-amber-500 text-black border-amber-600 font-bold' : 'bg-black border-white/10 text-white/50'}`}
                            >
                              Dibujar Trazos
                            </button>
                          </div>
                        </div>

                        {signatureMode === 'type' ? (
                          <div>
                            <input
                              id={`typed-signature-input-${order.id}`}
                              type="text"
                              required
                              value={typedName[order.id] || ''}
                              onChange={(e) => setTypedName({ ...typedName, [order.id]: e.target.value })}
                              placeholder="Teclea tu nombre completo..."
                              className="w-full bg-black border border-white/10 text-amber-500 p-2 text-xs font-serif tracking-wide rounded-sm focus:outline-none focus:border-amber-500"
                            />
                            {typedName[order.id] && (
                              <p className="text-[11px] text-white/35 mt-1 font-mono text-right italic font-light">
                                Sello Autógrafo: <span className="text-amber-500 font-semibold font-serif ml-1">/ {typedName[order.id]} /</span>
                              </p>
                            )}
                          </div>
                        ) : (
                          <div className="space-y-1.5">
                            <div className="h-28 bg-black border border-white/10 rounded-sm relative flex flex-col justify-center items-center overflow-hidden">
                              <span className="text-[10px] text-amber-400 opacity-60 italic font-mono uppercase select-none">
                                {typedName[order.id] || 'Panel de Trazo'}
                              </span>
                              <p className="text-[9px] text-white/30 text-center select-none max-w-[200px] mt-1 z-0">
                                Haz clic y desliza el mouse o usa tu dedo en este cuadro para plasmar tu firma.
                              </p>
                              <canvas
                                className="absolute inset-0 z-10 cursor-crosshair h-full w-full"
                                id={`signature-canvas-${order.id}`}
                                onMouseDown={(e) => startPaint(order.id, e)}
                                onMouseMove={(e) => drawPaint(order.id, e)}
                                onMouseUp={() => stopPaint(order.id)}
                                onMouseLeave={() => stopPaint(order.id)}
                                onTouchStart={(e) => startPaintTouch(order.id, e)}
                                onTouchMove={(e) => drawPaintTouch(order.id, e)}
                                onTouchEnd={() => stopPaint(order.id)}
                              />
                            </div>
                            <div className="flex justify-between items-center text-[10px] text-white/40">
                              <span>Trazo vectorizado en tiempo real.</span>
                              <button
                                id={`clear-canvas-${order.id}`}
                                type="button"
                                onClick={() => clearCanvas(order.id)}
                                className="text-[9.5px] font-bold text-amber-500 hover:text-white cursor-pointer"
                              >
                                Limpiar trazo
                              </button>
                            </div>
                          </div>
                        )}
                      </div>

                      <button
                        id={`btn-submit-reception-${order.id}`}
                        type="button"
                        disabled={signatureMode === 'type' ? !typedName[order.id] : (!typedName[order.id] && !isCanvasDrawn(order.id))}
                        onClick={() => {
                          const sig = signatureMode === 'type'
                            ? typedName[order.id]
                            : getCanvasImage(order.id) || typedName[order.id] || 'Firma Conforme';
                          const checkVal = receivedCheck[order.id] !== false;
                          const comms = comments[order.id] || 'He de constatar que todo está correcto.';
                          
                          onConfirmOrderReceipt(order.id, sig, checkVal, comms);
                        }}
                        className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs uppercase rounded-sm cursor-pointer disabled:opacity-40 transition-all tracking-wider"
                      >
                        ✔ Certificar Recepción, Firmar Domicilio y Finalizar
                      </button>

                    </div>
                  </div>
                )}

                {/* RF13: Display Receipt Audit when order is Entregado */}
                {order.status === 'Entregado' && (
                  <div className="border-t border-white/10 p-4 bg-emerald-500/5 text-xs text-white space-y-3 font-sans">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-bold uppercase tracking-wider text-[10px]">
                      <CheckCircle2 className="h-4 w-4 text-emerald-450 shrink-0" />
                      <span>Constancia de Recepción Registrada (RF13)</span>
                    </div>

                    <div className="p-3.5 bg-black/40 border border-emerald-900/30 rounded-sm leading-relaxed space-y-1.5 text-[11px] text-white/80">
                      <div className="flex justify-between border-b border-white/5 pb-1 mb-1 font-mono text-[9.5px] text-white/40">
                        <span>ACTA: ENT-{order.id.substring(2, 8).toUpperCase()}</span>
                        <span>{order.deliveryConfirmedAt ? new Date(order.deliveryConfirmedAt).toLocaleString() : 'N/A'}</span>
                      </div>
                      <div>🍳 Chef Calificado Asignado: <strong className="text-white font-medium">{order.preparerName || 'Staff Cocina'}</strong></div>
                      <div>🛵 Conductor Encargado: <strong className="text-white font-medium">{order.assignedDriver?.fullName || 'Servicio Expreso'}</strong> ({order.assignedDriver?.vehicleType})</div>
                      {order.recipientComments && (
                        <div className="italic text-white/60 text-[10.5px] mt-1.5 p-2 bg-black/70 rounded border border-white/5">
                          " {order.recipientComments} "
                        </div>
                      )}

                      {order.signatureSvg && (
                        <div className="mt-2.5 pt-2 border-t border-dashed border-white/10 flex items-center justify-between">
                          <span className="text-[9px] text-white/40 uppercase">Firma Digital del Recipiente:</span>
                          <div className="h-8 max-w-[150px] flex items-center justify-center p-1 bg-white/5 border border-white/10 rounded-sm">
                            {order.signatureSvg.startsWith('data:image') ? (
                              <img src={order.signatureSvg} alt="Sello Firma" className="h-full object-contain invert opacity-75" referrerPolicy="no-referrer" />
                            ) : (
                              <span className="font-cursive text-amber-500 text-[11.5px] italic font-semibold leading-none">/ {order.signatureSvg} /</span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* RF 8: Limit action bar (30 minutes cancellation logic) */}
                <div className="p-4 bg-white/5 border-t border-white/10 px-5 flex flex-wrap gap-4 items-center justify-between">
                  {order.status === 'Cancelado' ? (
                    <div className="flex items-center gap-1.5 text-xs text-rose-400 font-bold">
                      <Ban className="h-4 w-4" />
                      <span>Este pedido ya fue cancelado.</span>
                    </div>
                  ) : canModify ? (
                    <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between w-full">
                      <div className="flex items-center space-x-2 text-xs font-semibold text-amber-500 animate-pulse">
                        <Clock className="h-4 w-4 text-amber-500" />
                        <span>Ventana de cambio disponible: <strong className="font-mono bg-black border border-white/10 px-1.5 py-0.5 rounded-sm ml-1 text-white">{countdown}</strong> min</span>
                      </div>
                      
                      <div className="flex gap-3 justify-end w-full sm:w-auto">
                        <button
                          id={`btn-modify-${order.id}`}
                          onClick={() => onModifyOrder(order)}
                          className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-white text-xs font-semibold rounded-sm border border-white/10 transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <Edit3 className="h-3.5 w-3.5" />
                          <span>Modificar</span>
                        </button>

                        <button
                          id={`btn-cancel-${order.id}`}
                          onClick={() => onCancelOrder(order.id)}
                          className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold border border-rose-500/30 rounded-sm transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <Ban className="h-3.5 w-3.5" />
                          <span>Cancelar</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 p-2 px-3 bg-black border border-white/10 rounded-sm w-full text-xs text-white/50 leading-tight">
                      <ShieldAlert className="h-4.5 w-4.5 text-white/40 shrink-0" />
                      <span>
                        Soporte de Facturación: Han transcurrido más de <strong className="text-white font-sans font-bold">30 minutos</strong> desde que se procesó el pedido. No es posible editar ni anular de forma autónoma.
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
