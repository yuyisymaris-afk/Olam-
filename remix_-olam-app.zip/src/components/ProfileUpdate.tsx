import { useState, useRef, useEffect } from 'react';
import { User } from '../types';
import { Mail, Phone, User as UserIcon, MapPin, CheckCircle2, AlertCircle, Edit2, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

interface ProfileUpdateProps {
  currentUser: User;
  onUpdateUser: (updatedUser: User) => void;
}

type ActiveField = 'email' | 'phone' | 'username' | 'address' | null;

export default function ProfileUpdate({ currentUser, onUpdateUser }: ProfileUpdateProps) {
  const [activeField, setActiveField] = useState<ActiveField>(null);
  
  // Field values
  const [email, setEmail] = useState(currentUser.email);
  const [phone, setPhone] = useState(currentUser.phone);
  const [username, setUsername] = useState(currentUser.username);
  const [address, setAddress] = useState(currentUser.address);

  // Status message
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Refs for focusing
  const emailRef = useRef<HTMLInputElement>(null);
  const phoneRef = useRef<HTMLInputElement>(null);
  const usernameRef = useRef<HTMLInputElement>(null);
  const addressRef = useRef<HTMLInputElement>(null);

  // Automatically focus on the selected editable field
  useEffect(() => {
    if (activeField === 'email') emailRef.current?.focus();
    if (activeField === 'phone') phoneRef.current?.focus();
    if (activeField === 'username') usernameRef.current?.focus();
    if (activeField === 'address') addressRef.current?.focus();
  }, [activeField]);

  const handleSaveField = (field: 'email' | 'phone' | 'username' | 'address') => {
    setErrorMsg('');
    setSuccessMsg('');

    let updatedValue = '';
    if (field === 'email') updatedValue = email;
    if (field === 'phone') updatedValue = phone;
    if (field === 'username') updatedValue = username;
    if (field === 'address') updatedValue = address;

    if (!updatedValue || updatedValue.trim() === '') {
      setErrorMsg('El campo no puede estar vacío.');
      return;
    }

    const updatedUser: User = {
      ...currentUser,
      email: field === 'email' ? email : currentUser.email,
      phone: field === 'phone' ? phone : currentUser.phone,
      username: field === 'username' ? username : currentUser.username,
      address: field === 'address' ? address : currentUser.address,
    };

    onUpdateUser(updatedUser);
    setSuccessMsg(`¡${getFieldLabel(field)} actualizado con éxito!`);
    setActiveField(null);
  };

  const getFieldLabel = (field: 'email' | 'phone' | 'username' | 'address') => {
    if (field === 'email') return 'Correo electrónico';
    if (field === 'phone') return 'Número de celular';
    if (field === 'username') return 'Nombre de usuario';
    if (field === 'address') return 'Dirección de entrega';
    return '';
  };

  return (
    <div id="profile-update-container" className="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8 font-sans">
      <div className="bg-[#0F0F0F] border border-white/10 rounded-sm shadow-xl overflow-hidden">
        {/* Banner with avatar detail */}
        <div className="p-6 bg-gradient-to-r from-amber-500/10 to-[#0A0A0A] border-b border-white/10 flex items-center space-x-4">
          <div className="h-14 w-14 bg-amber-500 text-black rounded-sm flex items-center justify-center font-bold text-lg shadow-md">
            {currentUser.fullName ? currentUser.fullName[0].toUpperCase() : 'U'}
          </div>
          <div>
            <h2 id="profile-fullname" className="text-xl font-light tracking-tight text-white uppercase">{currentUser.fullName}</h2>
            <div className="flex items-center gap-1.5 mt-0.5">
              <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
              <span className="text-[10px] text-white/50 uppercase tracking-wider">CC Verificada: <span className="text-white font-mono font-semibold">{currentUser.ccNumber || '101456***'}</span></span>
            </div>
          </div>
        </div>

        {/* Action Panel to quickly go to the field to update (RF 5) */}
        <div className="p-6 space-y-5">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#ff8c38] font-bold">RF 5: Actualizar Datos de Perfil</p>
            <h3 className="text-lg font-light text-white uppercase tracking-tight mt-0.5">Configuración de Cuenta</h3>
            <p className="text-xs text-white/50 leading-relaxed mt-1">
              Selecciona el dato específico que deseas modificar. El sistema te llevará directamente a editar el campo indicado, bloqueando los cambios no deseados para tu seguridad.
            </p>
          </div>

          {/* Toast / Message Indicators */}
          {successMsg && (
            <div id="update-success-alert" className="p-3 bg-emerald-950/20 border border-emerald-900/30 text-emerald-450 rounded-sm flex items-center gap-2.5 text-xs">
              <CheckCircle2 className="h-4.5 w-4.5 shrink-0 text-emerald-500" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div id="update-error-alert" className="p-3 bg-rose-950/20 border border-rose-900/30 text-rose-450 rounded-sm flex items-center gap-2.5 text-xs">
              <AlertCircle className="h-4.5 w-4.5 shrink-0 text-rose-550" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Quick Jump / Editable fields */}
          <div id="editable-fields-stack" className="space-y-3.5">
            {/* 1. Nombre de Usuario */}
            <div className={`p-4 rounded-sm border transition-all ${activeField === 'username' ? 'bg-[#0A0A0A] border-amber-500' : 'bg-white/5 border-white/5'}`}>
              <div className="flex items-center justify-between pointer-events-none mb-1">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-white/40 flex items-center gap-1.5">
                  <UserIcon className="h-3.5 w-3.5 text-white/30" />
                  Nombre de Usuario
                </span>
                {activeField !== 'username' && (
                  <button
                    id="edit-btn-username"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveField('username');
                    }}
                    className="pointer-events-auto text-[10px] font-bold text-amber-500 hover:text-amber-450 uppercase tracking-widest flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <Edit2 className="h-3 w-3" />
                    Modificar
                  </button>
                )}
              </div>

              {activeField === 'username' ? (
                <div className="flex gap-2 mt-2">
                  <input
                    id="input-username"
                    ref={usernameRef}
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 text-white px-3 py-1.5 text-xs rounded-sm focus:outline-none focus:border-amber-500 font-sans"
                  />
                  <button
                    id="save-username-btn"
                    onClick={() => handleSaveField('username')}
                    className="px-3 py-1 bg-amber-500 hover:bg-[#ff8c38] text-black text-xs font-semibold rounded-sm tracking-wide transition-colors cursor-pointer"
                  >
                    Guardar
                  </button>
                  <button
                    id="cancel-username-btn"
                    onClick={() => {
                      setUsername(currentUser.username);
                      setActiveField(null);
                    }}
                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-white/80 text-xs rounded-sm transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <p id="display-username" className="text-sm font-semibold text-white mt-1 pl-5">{currentUser.username}</p>
              )}
            </div>

            {/* 2. Correo Electrónico */}
            <div className={`p-4 rounded-sm border transition-all ${activeField === 'email' ? 'bg-[#0A0A0A] border-amber-500' : 'bg-white/5 border-white/5'}`}>
              <div className="flex items-center justify-between pointer-events-none mb-1">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-white/40 flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5 text-white/30" />
                  Correo Electrónico
                </span>
                {activeField !== 'email' && (
                  <button
                    id="edit-btn-email"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveField('email');
                    }}
                    className="pointer-events-auto text-[10px] font-bold text-amber-500 hover:text-amber-450 uppercase tracking-widest flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <Edit2 className="h-3 w-3" />
                    Modificar
                  </button>
                )}
              </div>

              {activeField === 'email' ? (
                <div className="flex gap-2 mt-2">
                  <input
                    id="input-email"
                    ref={emailRef}
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 text-white px-3 py-1.5 text-xs rounded-sm focus:outline-none focus:border-amber-500 font-sans"
                  />
                  <button
                    id="save-email-btn"
                    onClick={() => handleSaveField('email')}
                    className="px-3 py-1 bg-amber-500 hover:bg-[#ff8c38] text-black text-xs font-semibold rounded-sm tracking-wide transition-colors cursor-pointer"
                  >
                    Guardar
                  </button>
                  <button
                    id="cancel-email-btn"
                    onClick={() => {
                      setEmail(currentUser.email);
                      setActiveField(null);
                    }}
                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-white/80 text-xs rounded-sm transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <p id="display-email" className="text-sm font-semibold text-white mt-1 pl-5">{currentUser.email}</p>
              )}
            </div>

            {/* 3. Número de Celular */}
            <div className={`p-4 rounded-sm border transition-all ${activeField === 'phone' ? 'bg-[#0A0A0A] border-amber-500' : 'bg-white/5 border-white/5'}`}>
              <div className="flex items-center justify-between pointer-events-none mb-1">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-white/40 flex items-center gap-1.5">
                  <Phone className="h-3.5 w-3.5 text-white/30" />
                  Número Celular
                </span>
                {activeField !== 'phone' && (
                  <button
                    id="edit-btn-phone"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveField('phone');
                    }}
                    className="pointer-events-auto text-[10px] font-bold text-amber-500 hover:text-amber-450 uppercase tracking-widest flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <Edit2 className="h-3 w-3" />
                    Modificar
                  </button>
                )}
              </div>

              {activeField === 'phone' ? (
                <div className="flex gap-2 mt-2">
                  <input
                    id="input-phone"
                    ref={phoneRef}
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 text-white px-3 py-1.5 text-xs rounded-sm focus:outline-none focus:border-amber-500 font-sans"
                  />
                  <button
                    id="save-phone-btn"
                    onClick={() => handleSaveField('phone')}
                    className="px-3 py-1 bg-amber-500 hover:bg-[#ff8c38] text-black text-xs font-semibold rounded-sm tracking-wide transition-colors cursor-pointer"
                  >
                    Guardar
                  </button>
                  <button
                    id="cancel-phone-btn"
                    onClick={() => {
                      setPhone(currentUser.phone);
                      setActiveField(null);
                    }}
                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-white/80 text-xs rounded-sm transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <p id="display-phone" className="text-sm font-semibold text-white mt-1 pl-5">{currentUser.phone}</p>
              )}
            </div>

            {/* 4. Dirección */}
            <div className={`p-4 rounded-sm border transition-all ${activeField === 'address' ? 'bg-[#0A0A0A] border-amber-500' : 'bg-white/5 border-white/5'}`}>
              <div className="flex items-center justify-between pointer-events-none mb-1">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-white/40 flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-white/30" />
                  Dirección de Entrega
                </span>
                {activeField !== 'address' && (
                  <button
                    id="edit-btn-address"
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveField('address');
                    }}
                    className="pointer-events-auto text-[10px] font-bold text-[#ff8c38] hover:text-[#fff] uppercase tracking-widest flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <Edit2 className="h-3 w-3" />
                    Modificar
                  </button>
                )}
              </div>

              {activeField === 'address' ? (
                <div className="flex gap-2 mt-2">
                  <input
                    id="input-address"
                    ref={addressRef}
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 text-white px-3 py-1.5 text-xs rounded-sm focus:outline-none focus:border-amber-500 font-sans"
                  />
                  <button
                    id="save-address-btn"
                    onClick={() => handleSaveField('address')}
                    className="px-3 py-1 bg-amber-500 hover:bg-[#ff8c38] text-black text-xs font-semibold rounded-sm tracking-wide transition-colors cursor-pointer"
                  >
                    Guardar
                  </button>
                  <button
                    id="cancel-address-btn"
                    onClick={() => {
                      setAddress(currentUser.address);
                      setActiveField(null);
                    }}
                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-white/80 text-xs rounded-sm transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <p id="display-address" className="text-sm font-semibold text-white mt-1 pl-5">{currentUser.address}</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
