import React, { useState } from 'react';
import { User } from '../types';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
  registeredUsers: User[];
}

export function Login({ onLoginSuccess, registeredUsers }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Por favor diligencie todos los campos.');
      return;
    }

    // Match by email or username
    const user = registeredUsers.find(
      (u) => 
        (u.email.toLowerCase() === email.toLowerCase() || u.username.toLowerCase() === email.toLowerCase()) && 
        u.password === password
    );

    if (user) {
      onLoginSuccess(user);
    } else {
      setError('Usuario o contraseña incorrectos.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md mx-auto p-6 bg-[#0F0F0F] border border-white/10 rounded-sm text-white">
      <div className="space-y-1">
        <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40">
          Email o Usuario
        </label>
        <input
          type="text"
          placeholder="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full bg-white/5 border border-white/10 text-white px-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
        />
      </div>

      <div className="space-y-1">
        <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40">
          Contraseña
        </label>
        <input
          type="password"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full bg-white/5 border border-white/10 text-white px-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
        />
      </div>

      <button 
        type="submit"
        className="w-full mt-4 py-2 bg-amber-500 text-black font-semibold text-xs tracking-[0.2em] uppercase rounded-sm hover:bg-amber-400 transition-all cursor-pointer shadow-sm"
      >
        Entrar
      </button>

      {error && (
        <p className="p-2.5 bg-rose-950/20 border border-rose-900/30 text-rose-450 rounded-sm text-[11px] text-center mt-3 font-sans">
          {error}
        </p>
      )}
    </form>
  );
}

export default Login;
