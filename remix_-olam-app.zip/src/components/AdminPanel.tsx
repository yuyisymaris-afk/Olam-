import React, { useState } from 'react';
import { Order, OrderStatus, Driver, IngredientStock } from '../types';
import { 
  ClipboardList, 
  Shield, 
  RefreshCw, 
  Layers, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Package, 
  ChefHat, 
  CheckSquare,
  Truck,
  FileText,
  AlertTriangle,
  Plus,
  Trash2,
  CheckCircle2,
  Calendar,
  MessageSquare,
  UserCheck
} from 'lucide-react';
import { motion } from 'motion/react';

interface AdminPanelProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  drivers: Driver[];
  stock: IngredientStock[];
  onRegisterDriver: (newDriver: Driver) => void;
  onDeleteDriver: (driverId: string) => void;
  onRestockIngredient: (id: string, amount: number) => void;
  onAssignPreparerAndDriver: (orderId: string, preparerName: string, driver: Driver) => void;
}

export default function AdminPanel({
  orders,
  onUpdateOrderStatus,
  drivers,
  stock,
  onRegisterDriver,
  onDeleteDriver,
  onRestockIngredient,
  onAssignPreparerAndDriver,
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'orders' | 'inventory' | 'drivers' | 'receipts'>('orders');
  const [filterStatus, setFilterStatus] = useState<string>('Todos');

  // Assignee selections per order temporary state
  const [selectedChef, setSelectedChef] = useState<{ [orderId: string]: string }>({});
  const [selectedDriverId, setSelectedDriverId] = useState<{ [orderId: string]: string }>({});

  // Restock amount input state
  const [restockAmount, setRestockAmount] = useState<{ [ingId: string]: string }>({});

  // New Driver Form Inputs
  const [drvName, setDrvName] = useState('');
  const [drvCc, setDrvCc] = useState('');
  const [drvVeh, setDrvVeh] = useState<'Motocicleta' | 'Bicicleta' | 'Automóvil'>('Motocicleta');
  const [drvPlate, setDrvPlate] = useState('');
  const [drvError, setDrvError] = useState('');
  const [drvSuccess, setDrvSuccess] = useState('');

  const filteredOrders = orders.filter((order) => {
    return filterStatus === 'Todos' || order.status === filterStatus;
  });

  const completedOrders = orders.filter((order) => order.status === 'Entregado');

  const calculateTotalSales = () => {
    return orders
      .filter((o) => o.status !== 'Cancelado')
      .reduce((total, o) => total + o.total, 0);
  };

  const calculateSalesByStatus = (status: OrderStatus) => {
    return orders.filter((o) => o.status === status).length;
  };

  const formattedPrice = (price: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getStatusBadgeColor = (status: OrderStatus) => {
    if (status === 'Pendiente') return 'bg-amber-500/10 border-amber-500/30 text-amber-500';
    if (status === 'En Preparación') return 'bg-indigo-500/10 border-indigo-500/30 text-indigo-450';
    if (status === 'Enviado') return 'bg-sky-500/10 border-sky-500/30 text-sky-400';
    if (status === 'Entregado') return 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
    return 'bg-rose-500/10 border-rose-500/30 text-rose-450';
  };

  const totalCompleted = calculateSalesByStatus('Entregado');
  const totalPending = calculateSalesByStatus('Pendiente');
  const totalPreparing = calculateSalesByStatus('En Preparación');
  const totalCancelled = calculateSalesByStatus('Cancelado');

  // Driver Submission
  const handleCreateDriver = (e: React.FormEvent) => {
    e.preventDefault();
    setDrvError('');
    setDrvSuccess('');

    if (!drvName || !drvCc) {
      setDrvError('Por favor complete los campos obligatorios (Nombre y Cédula).');
      return;
    }

    const newDriver: Driver = {
      id: `drv-${Date.now()}`,
      fullName: drvName,
      ccNumber: drvCc,
      vehicleType: drvVeh,
      plate: drvVeh === 'Bicicleta' ? 'N/A' : drvPlate || 'SIN PLACA',
      isAvailable: true,
    };

    onRegisterDriver(newDriver);
    setDrvSuccess(`¡Conductor ${drvName} registrado con éxito!`);
    setDrvName('');
    setDrvCc('');
    setDrvPlate('');
    
    setTimeout(() => {
      setDrvSuccess('');
    }, 3000);
  };

  return (
    <div id="admin-dashboard-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 font-sans space-y-8">
      
      {/* Admin Title Banner */}
      <div className="bg-[#0F0F0F] p-6 rounded-sm border border-white/10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-xs text-amber-500 font-bold uppercase tracking-wider font-mono">
            <Shield className="h-4 w-4" />
            Consola Máster de Administración
          </div>
          <h2 className="text-xl font-light text-white uppercase tracking-tight">Centro Operativo Delicia Express</h2>
          <p className="text-xs text-white/50">
            Control de inventario de materias primas, logística de asignación de conductores y auditoría de actas firmadas en tiempo real.
          </p>
        </div>

        {/* Bento/Tab Switch selector */}
        <div className="flex flex-wrap gap-2">
          {['Todos', 'Pendiente', 'En Preparación', 'Enviado', 'Entregado', 'Cancelado'].map((st) => (
            <button
              key={st}
              onClick={() => {
                setFilterStatus(st);
                setActiveTab('orders'); // Jump to orders automatically if filtering orders
              }}
              className={`px-3 py-1.5 rounded-sm text-xs font-semibold border transition-all cursor-pointer ${
                filterStatus === st && activeTab === 'orders'
                  ? 'bg-amber-500 border-amber-600 text-black font-bold'
                  : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Admin metrics bento stack */}
      <div id="admin-bento-metrics" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0F0F0F] border border-white/10 rounded-sm flex items-center space-x-3.5">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-sm">
            <DollarSign className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest block leading-none">Ventas Totales</span>
            <p className="text-sm sm:text-base font-bold text-white mt-1 font-mono">{formattedPrice(calculateTotalSales())}</p>
          </div>
        </div>

        <div className="p-4 bg-[#0F0F0F] border border-white/10 rounded-sm flex items-center space-x-3.5">
          <div className="p-3 bg-amber-500/10 text-amber-500 rounded-sm">
            <Package className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest block leading-none">Nuevos Pendientes</span>
            <p className="text-sm sm:text-base font-bold text-white mt-1 font-mono">{totalPending} órdenes</p>
          </div>
        </div>

        <div className="p-4 bg-[#0F0F0F] border border-white/10 rounded-sm flex items-center space-x-3.5">
          <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-sm">
            <ChefHat className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest block leading-none">En Cocina</span>
            <p className="text-sm sm:text-base font-bold text-white mt-1 font-mono">{totalPreparing} platos</p>
          </div>
        </div>

        <div className="p-4 bg-[#0F0F0F] border border-white/10 rounded-sm flex items-center space-x-3.5">
          <div className="p-2 bg-white/5 text-sky-400 rounded-sm">
            <Truck className="h-5 w-5" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest block leading-none">Conductores Activos</span>
            <p className="text-sm sm:text-base font-bold text-white mt-1 font-mono">
              {drivers.filter(d => !d.isAvailable).length} en ruta / {drivers.length} total
            </p>
          </div>
        </div>
      </div>

      {/* Tabs navigation list */}
      <div className="flex border-b border-white/10 gap-2 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3 px-4 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            activeTab === 'orders' ? 'border-amber-500 text-white font-bold' : 'border-transparent text-white/40 hover:text-white'
          }`}
        >
          📋 Cola de Pedidos
        </button>
        <button
          onClick={() => setActiveTab('inventory')}
          className={`pb-3 px-4 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            activeTab === 'inventory' ? 'border-amber-500 text-white font-bold' : 'border-transparent text-white/40 hover:text-white'
          }`}
        >
          📦 Control Inventario (RF9)
        </button>
        <button
          onClick={() => setActiveTab('drivers')}
          className={`pb-3 px-4 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            activeTab === 'drivers' ? 'border-amber-500 text-white font-bold' : 'border-transparent text-white/40 hover:text-white'
          }`}
        >
          🚚 Conductores & Logística (RF10)
        </button>
        <button
          onClick={() => setActiveTab('receipts')}
          className={`pb-3 px-4 text-xs font-semibold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
            activeTab === 'receipts' ? 'border-amber-500 text-white font-bold' : 'border-transparent text-white/40 hover:text-white'
          }`}
        >
          📄 Actas de Domicilios Firmadas (RF13)
        </button>
      </div>

      {/* Active Tab rendering */}
      <div>
        
        {/* TAB 1: ORDERS QUEUE */}
        {activeTab === 'orders' && (
          <div id="orders-tab-section" className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <ClipboardList className="h-4.5 w-4.5 text-white/55" />
                <h3 className="text-sm font-semibold text-white tracking-wider uppercase">Fases del Flujo de Entregas (RF14)</h3>
              </div>
              <span className="text-[10px] text-white/40 uppercase font-mono">Fase Actual del Filtro de Órdenes: {filterStatus}</span>
            </div>

            {filteredOrders.length === 0 ? (
              <div className="p-12 text-center bg-[#0F0F0F] border border-white/10 rounded-sm text-white/40 text-xs">
                Ninguna orden coincide con el estado seleccionado en el filtro.
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredOrders.map((order) => (
                  <div
                    key={order.id}
                    id={`admin-order-card-${order.id}`}
                    className="bg-[#0F0F0F] border border-white/10 rounded-sm overflow-hidden flex flex-col justify-between"
                  >
                    {/* Header bar */}
                    <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[9.5px] font-mono text-white/40 font-bold block mb-0.5">FOLIO: {order.id.toUpperCase()} (FACTURA: {order.invoiceId})</span>
                        <h4 className="font-bold text-white max-w-[200px] truncate">{order.customerName}</h4>
                        <p className="text-[10px] text-white/60 mt-0.5 font-mono">{order.customerPhone}</p>
                      </div>
                      <div className="text-right">
                        <span className={`px-2 py-0.5 rounded-sm border text-[9px] font-black tracking-wider uppercase ${getStatusBadgeColor(order.status)}`}>
                          {order.status}
                        </span>
                        <span className="block text-[8.5px] font-mono text-white/30 mt-1">Estimado: ~{order.estimatedArrivalMinutes} min</span>
                      </div>
                    </div>

                    {/* Order Details Body */}
                    <div className="p-4 flex-1 space-y-4 text-xs">
                      <div className="space-y-2">
                        <p className="text-[9.5px] font-mono text-amber-500 uppercase tracking-widest font-bold">Reseta personalizada ordenada</p>
                        <div className="space-y-2">
                          {order.items.map((item) => (
                            <div key={item.cartItemId} className="p-2.5 bg-white/5 rounded-sm border border-white/10 leading-tight">
                              <div className="flex justify-between font-semibold text-white items-baseline">
                                <span className="pr-3 text-white">{item.product.name} (x{item.quantity})</span>
                                <span className="font-mono text-[11px] text-white/70 shrink-0">{formattedPrice(item.totalPrice)}</span>
                              </div>

                              {/* Customizations details */}
                              {(item.removedIngredients.length > 0 || item.addedIngredients.length > 0) && (
                                <div className="mt-2 space-y-1 p-2 bg-black/60 border border-white/5 rounded-sm">
                                  {item.removedIngredients.map((rem) => (
                                    <p key={rem} className="text-[9.5px] text-rose-450 font-medium">
                                      ⚠️ EXCLUIR: {rem}
                                    </p>
                                  ))}
                                  {item.addedIngredients.map((add) => (
                                    <p key={add.name} className="text-[9.5px] text-emerald-400 font-semibold">
                                      ➕ INCLUIR: {add.name}
                                    </p>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Display assigned cook & courier (RF11) */}
                      {(order.preparerName || order.assignedDriver) ? (
                        <div className="p-3 bg-black/40 border border-white/5 rounded-sm space-y-2">
                          <p className="text-[9px] text-[#ff8c38] font-bold uppercase tracking-widest leading-none">Asignados del Pedido (RF11)</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                            {order.preparerName && (
                              <div className="flex items-center gap-1.5 text-white/70">
                                <ChefHat className="h-3.5 w-3.5 text-indigo-450 shrink-0" />
                                <span>Preparando: <strong className="text-white font-medium">{order.preparerName}</strong></span>
                              </div>
                            )}
                            {order.assignedDriver && (
                              <div className="flex items-center gap-1.5 text-white/70">
                                <Truck className="h-3.5 w-3.5 text-sky-450 shrink-0" />
                                <span>Domiciliario: <strong className="text-white font-medium">{order.assignedDriver.fullName}</strong></span>
                              </div>
                            )}
                          </div>
                        </div>
                      ) : null}

                      {/* Client Delivery details */}
                      <div className="pt-3 border-t border-white/10 grid grid-cols-2 gap-3 text-[10.5px]">
                        <div>
                          <p className="text-white/40 uppercase tracking-wider font-mono text-[8px]">Dirección de Domicilio</p>
                          <p className="text-white mt-0.5 font-medium truncate" title={order.customerAddress}>{order.customerAddress}</p>
                        </div>
                        <div>
                          <p className="text-white/40 uppercase tracking-wider font-mono text-[8px]">Forma de Pago / Cobro</p>
                          <p className="text-white font-bold font-mono mt-0.5">{order.paymentMethod} - <span className="text-amber-500 font-bold">{formattedPrice(order.total)}</span></p>
                        </div>
                      </div>
                    </div>

                    {/* Footer Actions (RF11 / RF14 Status and Assignee validator) */}
                    <div className="p-3 bg-white/5 border-t border-white/10">
                      
                      {/* PENDIENTE state: Must choose assignment before Chef preparation starts */}
                      {order.status === 'Pendiente' && (
                        <div className="space-y-3">
                          <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 text-amber-500 text-[10.5px] rounded-sm">
                            <span className="font-bold uppercase tracking-wider block">⚠️ RF11: Control Obligatorio de Asignación</span>
                            Para avanzar este pedido, designe al encargado de cocinarlo y el domiciliario que lo transportará.
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] text-white/40 uppercase font-mono mb-1">Cocinero / Preparador:</label>
                              <select
                                id={`chef-select-${order.id}`}
                                value={selectedChef[order.id] || ''}
                                onChange={(e) => setSelectedChef({ ...selectedChef, [order.id]: e.target.value })}
                                className="w-full bg-[#1A1A1A] border border-white/10 text-white text-[11px] p-2 rounded-sm focus:border-amber-500 focus:outline-none"
                              >
                                <option value="">-- Eliga Cocinero --</option>
                                <option value="Chef Rodrigo Bernal">Chef Rodrigo Bernal (Horno 1)</option>
                                <option value="Chef Lucía Mendieta">Chef Lucía Mendieta (Salsas & Parrilla)</option>
                                <option value="Chef Andrés Restrepo">Chef Andrés Restrepo (Hamburguesas)</option>
                              </select>
                            </div>
                            <div>
                              <label className="block text-[9px] text-white/40 uppercase font-mono mb-1">Domiciliario Registrado (RF10):</label>
                              <select
                                id={`driver-select-${order.id}`}
                                value={selectedDriverId[order.id] || ''}
                                onChange={(e) => setSelectedDriverId({ ...selectedDriverId, [order.id]: e.target.value })}
                                className="w-full bg-[#1A1A1A] border border-white/10 text-white text-[11px] p-2 rounded-sm focus:border-amber-500 focus:outline-none"
                              >
                                <option value="">-- Domiciliario --</option>
                                {drivers.map((d) => (
                                  <option key={d.id} value={d.id} disabled={!d.isAvailable}>
                                    {d.fullName} ({d.vehicleType}) {d.isAvailable ? ' - Disponible' : ' - Ocupado'}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>

                          <button
                            id={`btn-status-prepare-${order.id}`}
                            disabled={!selectedChef[order.id] || !selectedDriverId[order.id]}
                            onClick={() => {
                              const chosenDrv = drivers.find((d) => d.id === selectedDriverId[order.id]);
                              if (chosenDrv) {
                                onAssignPreparerAndDriver(order.id, selectedChef[order.id], chosenDrv);
                              }
                            }}
                            className="w-full py-1.5 bg-amber-500 hover:bg-[#ff8c38] text-black text-[10.5px] font-bold uppercase rounded-sm cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                          >
                            Asignar Responsables y Cocinar
                          </button>
                        </div>
                      )}

                      {/* EN PREPARACION state: can advance to DISPATCHED/ENVIADO */}
                      {order.status === 'En Preparación' && (
                        <div className="flex gap-2">
                          <button
                            id={`btn-status-ship-${order.id}`}
                            onClick={() => onUpdateOrderStatus(order.id, 'Enviado')}
                            className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold uppercase rounded-sm transition-colors cursor-pointer"
                          >
                            Completar Preparación y Despachar Pedido (Enviado) &rarr;
                          </button>
                          
                          <button
                            id={`btn-cancel-admin-prep-${order.id}`}
                            onClick={() => onUpdateOrderStatus(order.id, 'Cancelado')}
                            className="px-3 bg-red-650/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-[11px] rounded-sm"
                          >
                            Cancelar
                          </button>
                        </div>
                      )}

                      {/* ENVIADO state: waiting for client receipt signature. Cannot bypass directly manually inside simple admin flow without warning to preserve signature trace! */}
                      {order.status === 'Enviado' && (
                        <div className="space-y-2">
                          <div className="p-2 bg-sky-950/20 border border-sky-800/30 text-sky-400 text-[10px] rounded-sm flex items-start gap-1.5">
                            <AlertTriangle className="h-4 w-4 shrink-0 text-sky-400 mt-0.5" />
                            <span>
                              <strong>RF12: Pendiente de Firma.</strong> El domiciliario asignado ({order.assignedDriver?.fullName}) se encuentra en ruta. El cliente debe confirmar que recibió su pedido a conformidad y realizar su firma digital en el panel de facturación.
                            </span>
                          </div>

                          <div className="flex gap-2">
                            {/* Bypass for simulator/offline direct completion inside app frame */}
                            <button
                              id={`btn-bypass-signature-${order.id}`}
                              onClick={() => {
                                const confirmBypass = window.confirm('¿Deseas simular la firma de entrega por parte del cliente directamente desde el panel administrador?');
                                if (confirmBypass) {
                                  onUpdateOrderStatus(order.id, 'Entregado');
                                }
                              }}
                              className="flex-1 py-1 px-2.5 bg-emerald-500 hover:bg-[#ff8c38] text-black text-[10.5px] font-bold rounded-sm uppercase cursor-pointer"
                            >
                              ✍️ Simular Entrega Con Firma Directa
                            </button>
                            
                            <button
                              id={`btn-cancel-admin-ship-${order.id}`}
                              onClick={() => onUpdateOrderStatus(order.id, 'Cancelado')}
                              className="px-3 bg-white/5 hover:bg-white/10 text-white/60 border border-white/10 text-[10px] rounded-sm"
                            >
                              Anular
                            </button>
                          </div>
                        </div>
                      )}

                      {/* COMPLETED or CANCELLED status logs */}
                      {(order.status === 'Entregado' || order.status === 'Cancelado') && (
                        <div className="flex items-center justify-between text-[11px] text-white/50">
                          <span>Estado Final Registrado</span>
                          <span className="font-mono text-[10px]">
                            {order.status === 'Entregado' ? `✅ Recibido: ${order.deliveryConfirmedAt ? new Date(order.deliveryConfirmedAt).toLocaleTimeString() : 'N/A'}` : '❌ Cancelado'}
                          </span>
                        </div>
                      )}

                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: INVENTORY STOCK MANAGEMENT (RF9) */}
        {activeTab === 'inventory' && (
          <div id="inventory-tab-section" className="space-y-6">
            <div className="p-6 bg-[#0A0A0A] border border-white/10 rounded-sm">
              <p className="text-[10px] uppercase tracking-[0.2em] text-amber-500 font-bold">RF9: Gestión de Stock y Abastecimiento</p>
              <h3 className="text-lg font-light text-white uppercase tracking-tight mt-0.5">Control de Materia Prima e Ingredientes</h3>
              <p className="text-xs text-white/55 leading-relaxed mt-1">
                El sistema descuenta automáticamente las porciones del inventario al confirmar los pedidos en base a la receta. Cuando el nivel baja del mínimo de seguridad, se emite una alerta para gestionar el pedido de reabastecimiento.
              </p>
            </div>

            {/* List Table of raw materials */}
            <div className="bg-[#0F0F0F] border border-white/10 rounded-sm overflow-hidden">
              <div className="p-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-white">Inventario en Tiempo Real</span>
                <span className="text-[10px] font-mono text-white/40">Total de Ingredientes: {stock.length}</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#050505] text-white/40 uppercase tracking-widest text-[9px] border-b border-white/10">
                    <tr>
                      <th className="p-4">Ingrediente Materia Prima</th>
                      <th className="p-4">Capacidad Actual</th>
                      <th className="p-4">Alerta de Seguridad</th>
                      <th className="p-4">Porcentaje Crítico</th>
                      <th className="p-4 text-right">Acción Reorden / Abastecimiento (RF9)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {stock.map((item) => {
                      const isLowStock = item.currentStock <= item.minStock;
                      const percentage = Math.min(100, Math.floor((item.currentStock / (item.minStock * 3)) * 100));
                      
                      return (
                        <tr key={item.id} className={`hover:bg-white/5 transition-colors ${isLowStock ? 'bg-amber-500/5' : ''}`}>
                          <td className="p-4 font-semibold text-white">
                            <div className="flex items-center gap-2">
                              <span className={`h-2 w-2 rounded-full ${isLowStock ? 'bg-amber-500 animate-ping' : 'bg-green-500'}`} />
                              {item.name}
                            </div>
                          </td>
                          <td className="p-4 font-mono font-bold text-white">
                            {item.currentStock} <span className="text-white/40 font-normal text-[10px]">{item.unit}</span>
                          </td>
                          <td className="p-4 font-mono">
                            Mínimo: {item.minStock} {item.unit}
                          </td>
                          <td className="p-4">
                            <div className="w-24 sm:w-32 bg-white/10 h-2 rounded-full overflow-hidden inline-block mr-2 align-middle">
                              <div 
                                className={`h-full rounded-full ${isLowStock ? 'bg-amber-500' : 'bg-emerald-500'}`} 
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                            <span className={`font-mono text-[10px] ${isLowStock ? 'text-amber-500 font-bold' : 'text-emerald-400'}`}>
                              {percentage}%
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <div className="inline-flex items-center gap-1.5">
                              {/* Restock manual actions */}
                              <button
                                onClick={() => onRestockIngredient(item.id, item.unit === 'g' ? 500 : 10)}
                                className="px-2 py-1 bg-white/5 hover:bg-white/10 text-white border border-white/10 text-[10px] rounded-sm cursor-pointer transition-colors"
                              >
                                +{item.unit === 'g' ? '500g' : '10 u'}
                              </button>
                              <button
                                onClick={() => onRestockIngredient(item.id, item.unit === 'g' ? 2000 : 50)}
                                className="px-2 py-1 bg-amber-500 hover:bg-[#ff8c38] text-black text-[10px] font-bold rounded-sm cursor-pointer transition-colors"
                              >
                                +{item.unit === 'g' ? '2kg' : '50 u'}
                              </button>

                              {/* Custom input amount restock */}
                              <div className="flex items-center gap-1 ml-2">
                                <input
                                  type="number"
                                  placeholder="Cant."
                                  value={restockAmount[item.id] || ''}
                                  onChange={(e) => setStockQtyInput(item.id, e.target.value)}
                                  className="w-12 bg-black border border-white/10 text-white py-0.5 px-1 text-[10px] text-center focus:outline-none focus:border-amber-500 rounded-sm"
                                />
                                <button
                                  disabled={!restockAmount[item.id]}
                                  onClick={() => {
                                    const qty = parseInt(restockAmount[item.id]);
                                    if (qty > 0) {
                                      onRestockIngredient(item.id, qty);
                                      setStockQtyInput(item.id, '');
                                    }
                                  }}
                                  className="p-1 bg-white/10 hover:bg-white/20 text-white rounded-sm disabled:opacity-30 cursor-pointer"
                                >
                                  <Plus className="h-3 w-3" />
                                </button>
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: REGISTER DRIVERS & DOMICILIO LOGISTICS (RF10) */}
        {activeTab === 'drivers' && (
          <div id="drivers-tab-section" className="space-y-6">
            
            {/* Split row: Form and lists */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Form to register new driver */}
              <div className="lg:col-span-1 p-6 bg-[#0F0F0F] border border-white/10 rounded-sm h-fit space-y-4">
                <div>
                  <p className="text-[9px] uppercase tracking-[0.2em] text-[#ff8c38] font-bold">RF10: Registro e Identificación</p>
                  <h3 className="text-base font-light text-white uppercase mt-0.5">Catalogar Conductor</h3>
                  <p className="text-xs text-white/55 leading-relaxed mt-1">
                    Registra e identifica a cada conductor de la flota de domicilios para poder asignarles pedidos (RF10 y RF11).
                  </p>
                </div>

                <form onSubmit={handleCreateDriver} className="space-y-3.5 text-xs">
                  {drvError && (
                    <div className="p-2.5 bg-rose-950/20 border border-rose-900/30 text-rose-450 rounded-sm">
                      {drvError}
                    </div>
                  )}
                  {drvSuccess && (
                    <div className="p-2.5 bg-emerald-950/20 border border-emerald-950/35 text-emerald-450 rounded-sm">
                      {drvSuccess}
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="block text-white/40 uppercase font-mono text-[9px]">Nombre Completo del Conductor*:</label>
                    <input
                      type="text"
                      required
                      value={drvName}
                      onChange={(e) => setDrvName(e.target.value)}
                      placeholder="Javier Estrada"
                      className="w-full bg-[#1A1A1A] border border-white/10 text-white px-3 py-2 rounded-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-white/40 uppercase font-mono text-[9px]">Cédula de Ciudadanía (CC)*:</label>
                    <input
                      type="text"
                      required
                      value={drvCc}
                      onChange={(e) => {
                        const val = e.target.value.replace(/\D/g, '');
                        setDrvCc(val);
                      }}
                      placeholder="1016785***"
                      maxLength={11}
                      className="w-full bg-[#1A1A1A] border border-white/10 text-white px-3 py-2 rounded-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-white/40 uppercase font-mono text-[9px]">Tipo de Vehículo de Despacho:</label>
                    <select
                      value={drvVeh}
                      onChange={(e) => {
                        const val = e.target.value as any;
                        setDrvVeh(val);
                        if (val === 'Bicicleta') setDrvPlate('');
                      }}
                      className="w-full bg-[#1A1A1A] border border-white/10 text-white px-3 py-2 rounded-sm focus:outline-none focus:border-amber-500"
                    >
                      <option value="Motocicleta">Motocicleta</option>
                      <option value="Bicicleta">Bicicleta</option>
                      <option value="Automóvil">Automóvil</option>
                    </select>
                  </div>

                  {drvVeh !== 'Bicicleta' && (
                    <div className="space-y-1">
                      <label className="block text-white/40 uppercase font-mono text-[9px]">Placa de Vehículo:</label>
                      <input
                        type="text"
                        value={drvPlate}
                        onChange={(e) => setDrvPlate(e.target.value.toUpperCase())}
                        placeholder="XYZ-45E"
                        maxLength={7}
                        className="w-full bg-[#1A1A1A] border border-white/10 text-white px-3 py-2 rounded-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2 bg-amber-500 hover:bg-[#ff8c38] text-black font-bold uppercase rounded-sm cursor-pointer transition-colors"
                  >
                    Guardar y Registrar Conductor
                  </button>
                </form>
              </div>

              {/* List of drivers */}
              <div className="lg:col-span-2 space-y-4">
                <div className="p-4 bg-white/5 border border-white/10 rounded-sm flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-white">Conductores y Disponibilidad Registrada</span>
                  <span className="text-[10px] font-mono text-white/40">Total: {drivers.length} Conductores</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {drivers.map((drv) => (
                    <div 
                      key={drv.id}
                      className="p-4 bg-[#0F0F0F] border border-white/10 rounded-sm flex flex-col justify-between"
                    >
                      <div className="space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-bold text-white uppercase text-xs">{drv.fullName}</h4>
                            <p className="text-[10px] text-white/50 font-mono">CC: {drv.ccNumber}</p>
                          </div>
                          
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold border ${
                            drv.isAvailable 
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-450' 
                              : 'bg-orange-500/10 border-orange-500/30 text-orange-450'
                          }`}>
                            {drv.isAvailable ? '✔ Disponible' : '⚡ En Ruta'}
                          </span>
                        </div>

                        <div className="pt-2 border-t border-white/5 grid grid-cols-2 text-[10.5px]">
                          <div>
                            <span className="text-white/40 font-mono text-[8px] block">VEHÍCULO</span>
                            <span className="text-white">{drv.vehicleType}</span>
                          </div>
                          <div>
                            <span className="text-white/40 font-mono text-[8px] block">PLACA / DISTINTIVO</span>
                            <span className="text-white font-mono">{drv.plate || 'N/A'}</span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-white/5 flex justify-end items-center gap-2">
                        {drv.currentOrderId && (
                          <span className="text-[9.5px] font-mono text-white/50 mr-auto truncate max-w-[100px]" title={`Orden ${drv.currentOrderId}`}>
                            Pedido: #{drv.currentOrderId.substring(0, 7)}...
                          </span>
                        )}
                        <button
                          onClick={() => {
                            if (drv.currentOrderId) {
                              alert('Este conductor tiene una entrega activa. Libéralo completando el pedido antes de borrarlo.');
                              return;
                            }
                            if (window.confirm(`¿Confirmas la eliminación del conductor ${drv.fullName}?`)) {
                              onDeleteDriver(drv.id);
                            }
                          }}
                          className="px-2 py-1 bg-red-950/40 hover:bg-red-950 text-red-400 border border-red-950/20 rounded-sm text-[10px] cursor-pointer transition-colors"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 4: DELIVERY RECEIPT DOCUMENTS & SECURE LOGS AUDITING (RF13) */}
        {activeTab === 'receipts' && (
          <div id="receipts-tab-section" className="space-y-6">
            <div className="p-6 bg-[#0A0A0A] border border-white/10 rounded-sm">
              <p className="text-[10px] uppercase tracking-[0.2em] text-emerald-400 font-bold">RF13: Constancia de Recepción Digitalizada</p>
              <h3 className="text-lg font-light text-white uppercase tracking-tight mt-0.5">Certificados de Entrega Oficiales (Dian / Dian-Sync)</h3>
              <p className="text-xs text-white/55 leading-relaxed mt-1">
                A continuación se listan las actas generadas automáticamente tras la entrega conforme del pedido. Cada registro contiene datos fiscales, el sello de tiempo exacto y la firma digitalizada del cliente.
              </p>
            </div>

            {completedOrders.length === 0 ? (
              <div className="p-12 text-center bg-[#0F0F0F] border border-white/10 rounded-sm text-white/40 text-xs">
                No hay actas de entrega firmadas todavía. Al confirmar el cliente la recepción de su domicilio (RF12) se generará aquí la auditoría.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {completedOrders.map((order) => (
                  <div 
                    key={order.id}
                    className="p-5 bg-[#0F0F0F] border border-white/10 rounded-sm font-sans space-y-4 shadow-lg text-xs"
                  >
                    {/* Header receipt stylized card */}
                    <div className="border-b border-dashed border-white/20 pb-3 flex justify-between items-start">
                      <div>
                        <span className="text-[8px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 font-mono uppercase font-extrabold rounded-sm">
                          ACTA REGISTRADA RF13
                        </span>
                        <h4 className="text-white mt-1.5 font-bold uppercase tracking-tight text-xs">ACTA #ENT-{order.id.substring(2, 8).toUpperCase()}</h4>
                        <p className="text-[10px] text-white/50">{order.customerAddress}</p>
                      </div>
                      <div className="text-right font-mono text-[9px] text-white/40">
                        <p>Factura: {order.invoiceId}</p>
                        <p className="mt-0.5">Fecha: {order.deliveryConfirmedAt ? new Date(order.deliveryConfirmedAt).toLocaleDateString() : 'N/A'}</p>
                      </div>
                    </div>

                    {/* Meta logistics details */}
                    <div className="grid grid-cols-2 gap-3 bg-black/40 p-2.5 rounded-sm border border-white/5 leading-normal text-[10.5px]">
                      <div>
                        <span className="text-[8.5px] font-mono text-white/40 uppercase block">Preparador Oficial (RF11)</span>
                        <span className="text-white font-medium">{order.preparerName || 'Sin Asignar (Presencial)'}</span>
                      </div>
                      <div>
                        <span className="text-[8.5px] font-mono text-white/40 uppercase block">Transportista (RF10)</span>
                        <span className="text-white font-medium">{order.assignedDriver?.fullName || 'Retiro Directo'}</span>
                      </div>
                    </div>

                    {/* Invoice detail row */}
                    <div>
                      <span className="text-[8.5px] font-mono text-white/30 uppercase block mb-1">Resumen Fiscal de Compra</span>
                      <div className="space-y-1">
                        {order.items.map(it => (
                          <div key={it.cartItemId} className="flex justify-between text-[11px] text-white/70">
                            <span>{it.product.name} (x{it.quantity})</span>
                            <span className="font-mono">{formattedPrice(it.totalPrice)}</span>
                          </div>
                        ))}
                        <div className="flex justify-between font-bold text-white text-[11.5px] pt-1.5 mt-1.5 border-t border-white/10">
                          <span>Total Recaudado ({order.paymentMethod})</span>
                          <span className="text-amber-500 font-mono">{formattedPrice(order.total)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Reception verification metrics */}
                    <div className="p-2.5 bg-neutral-900/40 rounded-sm space-y-1.5 border border-white/5 text-[10.5px]">
                      <div className="flex justify-between">
                        <span className="text-white/40">Chequeo de Conformidad:</span>
                        <span className={`font-bold ${order.receivedCorrectly ? 'text-emerald-450' : 'text-amber-500'}`}>
                          {order.receivedCorrectly ? '✔ Todo Correcto y Completo' : '⚠️ Posee Comentarios'}
                        </span>
                      </div>
                      <div>
                        <span className="text-white/40">Observaciones del Cliente:</span>
                        <p className="text-white font-medium italic mt-0.5">"{order.recipientComments || 'Sin comentarios'}"</p>
                      </div>
                    </div>

                    {/* Signature representation */}
                    <div className="pt-3 border-t border-dashed border-white/20">
                      <span className="text-[8.5px] font-mono text-white/30 uppercase block mb-1.5">Firma de Recibido Constancia Digital (RF12)</span>
                      
                      <div className="h-16 bg-white/5 border border-white/10 rounded-sm flex items-center justify-center relative overflow-hidden">
                        {order.signatureSvg ? (
                          <div className="absolute inset-0 flex items-center justify-center p-2">
                            {order.signatureSvg.startsWith('data:image') || order.signatureSvg.startsWith('<svg') ? (
                              <img 
                                src={order.signatureSvg} 
                                alt="Firma del cliente" 
                                className="max-h-full max-w-full object-contain invert opacity-80"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <span className="font-cursive text-amber-400 text-lg opacity-80 select-none">
                                {order.signatureSvg}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-[10px] text-white/30 italic">Firma Simulada / Administrativa</span>
                        )}
                        <div className="absolute bottom-1 right-2 text-[8px] font-mono text-white/20 select-none uppercase">
                          Sello Digital de Seguridad
                        </div>
                      </div>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );

  // Helper inside tab 2 stock input
  function setStockQtyInput(id: string, value: string) {
    setRestockAmount(prev => ({
      ...prev,
      [id]: value
    }));
  }
}
