import React, { useState, useRef, useEffect } from 'react';
import { User } from '../types';
import { Camera, Upload, AlertCircle, CheckCircle2, Lock, Mail, Phone, User as UserIcon, MapPin, Eye, EyeOff, Loader2, ArrowRight, RefreshCw, KeyRound } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AuthProps {
  onAuthSuccess: (user: User) => void;
  registeredUsers: User[];
  onRegisterUser: (user: User) => void;
}

type AuthTab = 'login' | 'register' | 'forgot-password';

export default function Auth({ onAuthSuccess, registeredUsers, onRegisterUser }: AuthProps) {
  const [activeTab, setActiveTab] = useState<AuthTab>('login');
  
  // Login State
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Register State
  const [regStep, setRegStep] = useState<1 | 2>(1); // 1 = Info, 2 = CC Photo Verification
  const [regUsername, setRegUsername] = useState('');
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regAddress, setRegAddress] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regError, setRegError] = useState('');

  // Age Verification State (Step 2)
  const [birthDate, setBirthDate] = useState('2000-01-01');
  const [ccNumber, setCcNumber] = useState('');
  const [photoMode, setPhotoMode] = useState<'camera' | 'upload' | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<{ verified: boolean; age: number; reason?: string } | null>(null);
  
  // Camera Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Forgot Password State
  const [forgotMethod, setForgotMethod] = useState<'email' | 'phone'>('email');
  const [forgotValue, setForgotValue] = useState('');
  const [forgotStep, setForgotStep] = useState<1 | 2 | 3>(1); // 1 = input, 2 = verification code, 3 = reset password
  const [sentCode, setSentCode] = useState('');
  const [enteredCode, setEnteredCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [recoveryError, setRecoveryError] = useState('');
  const [recoveredUser, setRecoveredUser] = useState<User | null>(null);

  // Stop camera when unmounting
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      setPhotoMode('camera');
      setCapturedImage(null);
      setScanResult(null);
      setRegError('');
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsCapturing(true);
    } catch (err) {
      console.error("Error accessing camera: ", err);
      // Fallback
      setPhotoMode('upload');
      setRegError('No pudimos acceder a tu cámara. Por favor sube una foto de tu cédula.');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCapturing(false);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');

      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        
        // Draw document guideline overlay on thumbnail too
        context.strokeStyle = '#f59e0b';
        context.lineWidth = 4;
        context.strokeRect(video.videoWidth * 0.1, video.videoHeight * 0.2, video.videoWidth * 0.8, video.videoHeight * 0.6);

        const dataUrl = canvas.toDataURL('image/jpeg');
        setCapturedImage(dataUrl);
        stopCamera();
        analyzeDocument(dataUrl);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCapturedImage(reader.result as string);
        analyzeDocument(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeDocument = (imageData: string) => {
    setScanning(true);
    setScanResult(null);
    setRegError('');

    // Simulate AI / OCR Document scanning
    setTimeout(() => {
      setScanning(false);
      
      // Calculate age from birthDate input
      const today = new Date();
      const birth = new Date(birthDate);
      let age = today.getFullYear() - birth.getFullYear();
      const m = today.getMonth() - birth.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
        age--;
      }

      const isOfAge = age >= 18;
      
      if (!isOfAge) {
        setScanResult({
          verified: false,
          age,
          reason: `Edad insuficiente: El sistema detecta que tienes ${age} años. Debes ser mayor de 18 años para registrarte.`
        });
      } else if (!ccNumber || ccNumber.trim().length < 6) {
        setScanResult({
          verified: false,
          age,
          reason: 'El número de cédula ingresado no es válido.'
        });
      } else {
        setScanResult({
          verified: true,
          age
        });
      }
    }, 2500);
  };

  const login = (usernameInput: string, passwordInput: string): boolean => {
    setLoginError('');

    if (!usernameInput || !passwordInput) {
      setLoginError('Por favor diligencie todos los campos.');
      return false;
    }

    const user = registeredUsers.find(
      (u) => (u.username.toLowerCase() === usernameInput.toLowerCase() || u.email.toLowerCase() === usernameInput.toLowerCase()) && u.password === passwordInput
    );

    if (user) {
      onAuthSuccess(user);
      return true;
    } else {
      setLoginError('Usuario o contraseña incorrectos.');
      return false;
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(loginUsername, loginPassword);
  };

  const handleRegisterStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regUsername || !regFullName || !regEmail || !regPhone || !regAddress || !regPassword) {
      setRegError('Por favor diligencie todos los campos requeridos.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('Las contraseñas no coinciden.');
      return;
    }

    // Check if user already exists
    const exists = registeredUsers.some(
      (u) => u.username.toLowerCase() === regUsername.toLowerCase() || u.email.toLowerCase() === regEmail.toLowerCase()
    );

    if (exists) {
      setRegError('El nombre de usuario o correo ya se encuentra registrado.');
      return;
    }

    // If passed validation, move to verification step 2
    setRegStep(2);
  };

  const handleFinalRegister = () => {
    if (!scanResult || !scanResult.verified) {
      setRegError('Debes completar una verificación de mayoría de edad válida.');
      return;
    }

    const newUser: User = {
      id: `u-${Date.now()}`,
      username: regUsername,
      fullName: regFullName,
      email: regEmail,
      phone: regPhone,
      address: regAddress,
      password: regPassword,
      isAgeVerified: true,
      ccNumber: ccNumber,
      birthDate: birthDate,
      ccPhotoUrl: capturedImage || 'https://images.unsplash.com/photo-1628157582853-a796fa650a6a?auto=format&fit=crop&q=80&w=200'
    };

    onRegisterUser(newUser);
    onAuthSuccess(newUser);
  };

  // Password Recovery Flow
  const handleRequestRecoveryCode = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    if (!forgotValue) {
      setRecoveryError('Ingrese su identificador (correo o número).');
      return;
    }

    // Attempt to locate user
    const user = registeredUsers.find((u) => {
      if (forgotMethod === 'email') {
        return u.email.toLowerCase() === forgotValue.toLowerCase();
      } else {
        return u.phone === forgotValue;
      }
    });

    if (!user) {
      setRecoveryError('No encontramos ninguna cuenta asociada a estos datos.');
      return;
    }

    // Found user
    setRecoveredUser(user);
    // Simulate generation of code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setSentCode(code);
    alert(`[Simulación de envío] Se ha enviado el código de verificación de 6 dígitos: ${code}`);
    setForgotStep(2);
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    if (enteredCode === sentCode) {
      setForgotStep(3);
    } else {
      setRecoveryError('Código incorrecto. Intente de nuevo.');
    }
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');

    if (!newPassword || newPassword.length < 4) {
      setRecoveryError('La contraseña debe tener al menos 4 caracteres.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setRecoveryError('Las contraseñas no coinciden.');
      return;
    }

    if (recoveredUser) {
      // Update user password in local registry
      const updatedUser = { ...recoveredUser, password: newPassword };
      onRegisterUser(updatedUser); // This updates or overwrites users
      
      alert('¡Contraseña actualizada con éxito! Ya puedes iniciar sesión.');
      setActiveTab('login');
      // Reset state
      setForgotStep(1);
      setForgotValue('');
      setEnteredCode('');
      setNewPassword('');
      setConfirmNewPassword('');
      setRecoveredUser(null);
    }
  };

  return (
    <div id="auth-container" className="flex items-center justify-center min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-md bg-[#0F0F0F] border border-white/10 rounded-sm shadow-2xl p-6 sm:p-8 relative overflow-hidden">
        {/* Background glow effects */}
        <div className="absolute top-0 left-1/4 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />

        {/* Tab Selector */}
        {forgotStep === 1 && (
          <div className="flex bg-[#0A0A0A] p-1 rounded-sm border border-white/10 mb-6 font-sans">
            <button
              id="tab-login"
              onClick={() => {
                setActiveTab('login');
                setRegStep(1);
              }}
              className={`flex-1 py-1.5 text-xs font-semibold uppercase tracking-wider rounded-sm transition-all cursor-pointer ${
                activeTab === 'login'
                  ? 'bg-amber-500 text-black font-semibold'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              Iniciar Sesión
            </button>
            <button
              id="tab-register"
              onClick={() => {
                setActiveTab('register');
              }}
              className={`flex-1 py-1.5 text-xs font-semibold uppercase tracking-wider rounded-sm transition-all cursor-pointer ${
                activeTab === 'register'
                  ? 'bg-amber-500 text-black font-semibold'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              Nuevo Cliente
            </button>
          </div>
        )}

        <AnimatePresence mode="wait">
          {activeTab === 'login' && forgotStep === 1 && (
            <motion.form
              key="login-form"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onSubmit={handleLogin}
              className="space-y-4"
            >
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-white/40">Bienvenido de nuevo</p>
                <h2 className="text-2xl font-light tracking-tighter text-white uppercase leading-none mt-1">Acceso de Cliente</h2>
                <p className="text-[11px] text-white/50 mt-1">Ingresa tus credenciales para acceder a tu menú preferido.</p>
              </div>

              {loginError && (
                <div id="login-error" className="p-3 bg-rose-950/20 border border-rose-900/30 text-rose-400 rounded-sm flex items-start gap-2 text-xs">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-rose-500" />
                  <span>{loginError}</span>
                </div>
              )}

              <div className="space-y-3.5 font-sans">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1.5">
                    Nombre de Usuario o Correo Electrónico
                  </label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-2.5 h-4 w-4 text-white/30" />
                    <input
                      id="login-username-input"
                      type="text"
                      placeholder="ej. carlos_chef o carlos@correo.com"
                      value={loginUsername}
                      onChange={(e) => setLoginUsername(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 text-white pl-10 pr-4 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40">
                      Contraseña
                    </label>
                    <button
                      id="forgot-password-link"
                      type="button"
                      onClick={() => {
                        setActiveTab('forgot-password');
                        setForgotStep(1);
                        setRecoveryError('');
                      }}
                      className="text-[9px] text-amber-500 hover:text-[#ff8c38] font-bold uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      ¿La olvidaste?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-white/30" />
                    <input
                      id="login-password-input"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 text-white pl-10 pr-10 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-mono"
                    />
                    <button
                      id="toggle-login-password"
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-white/44 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>

              <button
                id="login-submit"
                type="submit"
                className="w-full mt-6 py-2.5 bg-amber-500 text-black font-semibold text-xs tracking-[0.2em] uppercase rounded-sm hover:bg-[#ff8c38] transition-all cursor-pointer shadow-sm"
              >
                Ingresar al Sistema
              </button>
            </motion.form>
          )}

          {activeTab === 'register' && regStep === 1 && (
            <motion.form
              key="register-info"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onSubmit={handleRegisterStep1}
              className="space-y-3.5 text-xs font-sans"
            >
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-white/40">Nuevo Cliente</p>
                <h2 className="text-2xl font-light tracking-tighter text-white uppercase leading-none mt-1">Crear Cuenta</h2>
                <p className="text-[11px] text-white/50 mt-1">Paso 1 de 2: Información personal básica.</p>
              </div>

              {regError && (
                <div id="reg-error-1" className="p-3 bg-rose-950/20 border border-rose-900/30 text-rose-450 rounded-sm flex items-start gap-2 text-xs">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-rose-500" />
                  <span>{regError}</span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                    Nombre Completo
                  </label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-2.5 h-3.5 w-3.5 text-white/30" />
                    <input
                      id="reg-fullname"
                      type="text"
                      placeholder="Juan Pérez Gómez"
                      required
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 text-white pl-9 pr-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                    Usuario
                  </label>
                  <input
                    id="reg-username"
                    type="text"
                    placeholder="juanperez"
                    required
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-white px-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                    Celular
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-2.5 h-3.5 w-3.5 text-white/30" />
                    <input
                      id="reg-phone"
                      type="tel"
                      placeholder="3101234567"
                      required
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 text-white pl-9 pr-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                  Correo Electrónico
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 h-3.5 w-3.5 text-white/30" />
                  <input
                    id="reg-email"
                    type="email"
                    placeholder="juan@correo.com"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-white pl-9 pr-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                  Dirección de Entrega
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 h-3.5 w-3.5 text-white/30" />
                  <input
                    id="reg-address"
                    type="text"
                    placeholder="Calle 100 #24-12, Bogotá"
                    required
                    value={regAddress}
                    onChange={(e) => setRegAddress(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-white pl-9 pr-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                    Contraseña
                  </label>
                  <input
                    id="reg-password"
                    type="password"
                    placeholder="••••••••"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-white px-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                    Confirmar
                  </label>
                  <input
                    id="reg-password-confirm"
                    type="password"
                    placeholder="••••••••"
                    required
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 text-white px-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-mono"
                  />
                </div>
              </div>

              <button
                id="reg-submit-1"
                type="submit"
                className="w-full mt-4 py-2.5 bg-amber-500 text-black font-semibold text-xs rounded-sm hover:bg-[#ff8c38] active:bg-[#e06c15] uppercase tracking-[0.15em] flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm"
              >
                <span>Siguiente Paso: Verificar Edad</span>
                <ArrowRight className="h-3.5 w-3.5 stroke-[2.5]" />
              </button>
            </motion.form>
          )}

          {activeTab === 'register' && regStep === 2 && (
            <motion.div
              key="register-verification"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-white/40">RF 2: Mayoría de Edad</p>
                <h2 id="verificacion-titulo" className="text-2xl font-light tracking-tighter text-white uppercase leading-none mt-1">Verificación de CC</h2>
                <p className="text-[11px] text-white/50 mt-1">
                  Validación obligatoria mediante captura fotográfica de tu documento de identidad colombiano (Cédula de Ciudadanía).
                </p>
              </div>

              {regError && (
                <div id="reg-error-2" className="p-3 bg-rose-950/20 border border-rose-900/30 text-rose-450 rounded-sm flex items-start gap-2 text-xs font-sans">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-rose-500" />
                  <span>{regError}</span>
                </div>
              )}

              {/* Identity Form fields to support scanner evaluation */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-white/5 rounded-sm border border-white/10 font-sans">
                <div>
                  <label className="block text-[9px] uppercase tracking-wider text-white/40 mb-1">
                    Número de Cédula (CC)
                  </label>
                  <input
                    id="cc-number-input"
                    type="text"
                    required
                    placeholder="1014561234"
                    value={ccNumber}
                    onChange={(e) => setCcNumber(e.target.value)}
                    className="w-full bg-[#0A0A0A] border border-white/10 text-white px-2 py-1.5 text-xs rounded-sm focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-[9px] uppercase tracking-wider text-white/40 mb-1">
                    Fecha de Nacimiento
                  </label>
                  <input
                    id="birthdate-input"
                    type="date"
                    required
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full bg-[#0A0A0A] border border-white/10 text-white px-2 py-1.5 text-xs rounded-sm focus:outline-none focus:border-amber-500 focus:text-white"
                  />
                </div>
              </div>

              {/* Selection to start capturing */}
              {!isCapturing && !capturedImage && (
                <div className="flex flex-col gap-2.5 font-sans">
                  <button
                    id="btn-use-camera"
                    onClick={startCamera}
                    className="p-4 bg-white/5 border border-white/10 hover:border-amber-500/50 rounded-sm flex items-center justify-between text-left group transition-all cursor-pointer"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 bg-amber-500/10 text-amber-500 rounded-sm group-hover:bg-amber-500 group-hover:text-black transition-all">
                        <Camera className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-white uppercase tracking-wider">Tomar foto con cámara</p>
                        <p className="text-[10px] text-white/40">Requerido para validación instantánea</p>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-white/30 group-hover:text-white transition-colors" />
                  </button>

                  <div className="relative flex items-center justify-center my-1">
                    <span className="absolute bg-[#0F0F0F] px-4 text-[9px] uppercase tracking-[0.2em] text-white/40">O sube un archivo</span>
                    <div className="w-full border-t border-white/10" />
                  </div>

                  <div className="relative">
                    <input
                      id="cc-upload-file"
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                    <div className="p-4 border border-dashed border-white/10 hover:border-amber-500/40 rounded-sm text-center flex flex-col items-center gap-1 bg-white/5">
                      <Upload className="h-5 w-5 text-white/40 mb-1" />
                      <p className="text-xs font-semibold text-white/80">Seleccionar imagen desde tu dispositivo</p>
                      <p className="text-[10px] text-white/30">Soporta PNG, JPG o PDF de tu Cédula</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Camera Live Stream */}
              {isCapturing && (
                <div className="relative overflow-hidden rounded-sm border border-amber-500/30 bg-black aspect-video flex flex-col justify-end">
                  <video
                    id="video-stream"
                    ref={videoRef}
                    playsInline
                    muted
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  
                  {/* Guideline rectangle for document */}
                  <div className="absolute inset-10 border-2 border-dashed border-amber-500/50 rounded-sm pointer-events-none flex items-center justify-center bg-amber-500/[0.02]">
                    <span className="text-[9px] font-mono text-amber-500 bg-black/80 px-2 py-0.5 rounded-sm uppercase tracking-wider font-semibold">
                      Ubica el documento aquí
                    </span>
                  </div>

                  <div className="relative z-10 flex p-3 bg-black/95 gap-2 font-sans border-t border-white/10">
                    <button
                      id="btn-capture-snapshot"
                      onClick={capturePhoto}
                      className="flex-1 py-1.5 bg-amber-500 hover:bg-[#ff8c38] text-black text-xs font-semibold rounded-sm uppercase tracking-wider transition-colors cursor-pointer shadow"
                    >
                      Capturar Foto
                    </button>
                    <button
                      id="btn-cancel-capture"
                      onClick={stopCamera}
                      className="px-3 bg-white/5 hover:bg-white/10 text-white text-xs rounded-sm border border-white/10 uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}

              {/* Document Scanning effect */}
              {scanning && (
                <div className="p-6 bg-[#0A0A0A] border border-white/10 rounded-sm text-center space-y-4 relative overflow-hidden">
                  <div className="w-16 h-16 mx-auto relative flex items-center justify-center">
                    <Loader2 className="h-10 w-10 text-amber-500 animate-spin" />
                    {capturedImage && (
                      <img
                        src={capturedImage}
                        alt="CC Document Analysis"
                        className="absolute inset-0 w-full h-full object-cover rounded-sm opacity-30 blur-[1px]"
                      />
                    )}
                  </div>
                  {/* Laser bar animation */}
                  <div className="absolute left-0 right-0 h-1 bg-amber-500 shadow-md shadow-amber-500/50 animate-[bounce_2s_infinite]" />
                  
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-white tracking-wide uppercase">Analizando Cédula...</p>
                    <p className="text-[10px] text-white/40 font-mono">OCR Engine: Extrayendo marcas de agua y fecha de nacimiento</p>
                  </div>
                </div>
              )}

              {/* Capture Result & Validation Evaluation */}
              {capturedImage && !scanning && (
                <div className="space-y-3.5 font-sans">
                  <div className="relative aspect-video rounded-sm overflow-hidden border border-white/10">
                    <img
                      src={capturedImage}
                      alt="Cédula Capturada"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 right-2 bg-black/80 px-2 py-1 rounded-sm border border-white/10 flex items-center gap-1.5">
                      <span className="text-[9.5px] font-mono text-white/60 font-semibold uppercase tracking-wider">Foto cargada</span>
                      <button
                        id="btn-retry-photo"
                        onClick={() => {
                          setCapturedImage(null);
                          setScanResult(null);
                          setRegError('');
                        }}
                        className="text-amber-500 hover:text-amber-450 cursor-pointer"
                        title="Tomar otra foto"
                      >
                        <RefreshCw className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  {scanResult && (
                    <motion.div
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className={`p-4 rounded-sm border ${
                        scanResult.verified
                          ? 'bg-emerald-950/20 border-emerald-900/30 text-emerald-400'
                          : 'bg-rose-950/20 border-rose-900/30 text-rose-450'
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        {scanResult.verified ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-550 shrink-0 mt-0.5" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="text-xs font-semibold text-white uppercase tracking-wider">
                            {scanResult.verified ? 'Mayoría de Edad Confirmada' : 'No se pudo verificar la mayoría de edad'}
                          </p>
                          <p className="text-[11px] text-white/60 mt-0.5 font-mono">
                            CC: <span className="text-white font-sans font-bold">{ccNumber}</span> | Edad calculada:{' '}
                            <span className="text-white font-sans font-bold">{scanResult.age} años</span>
                          </p>
                          {!scanResult.verified && (
                            <p className="text-[11px] text-rose-400 mt-1.5 leading-relaxed font-sans font-medium">
                              {scanResult.reason}
                            </p>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}

                  <div className="flex gap-2.5 pt-2">
                    <button
                      id="btn-verification-back"
                      onClick={() => setRegStep(1)}
                      className="flex-1 py-2 bg-white/5 text-white hover:bg-white/10 border border-white/10 text-xs font-semibold rounded-sm transition-colors uppercase tracking-wider cursor-pointer"
                    >
                      Atrás
                    </button>
                    <button
                      id="btn-finish-registration"
                      onClick={handleFinalRegister}
                      disabled={!scanResult || !scanResult.verified}
                      className="flex-1 py-2 bg-amber-500 disabled:opacity-50 disabled:cursor-not-allowed text-black text-xs font-bold rounded-sm hover:bg-[#ff8c38] transition-all uppercase tracking-wider cursor-pointer shadow-sm"
                    >
                      Completar Registro
                    </button>
                  </div>
                </div>
              )}

              {/* Utility to easily generate positive outcome for developer test */}
              <div className="p-3 bg-white/5 rounded-sm border border-white/10 text-center font-sans">
                <span className="text-[9px] text-[#ff8c38] uppercase tracking-[0.2em] block mb-1">
                  💡 Simulador de Validación de CC (Mayor de Edad)
                </span>
                <p className="text-[10px] text-white/40 mb-2">
                  Coloca tu cédula de prueba. Ajusta la fecha de nacimiento para verificar el comportamiento de mayoría de edad.
                </p>
                <div className="flex gap-2 justify-center">
                  <button
                    id="simulate-verified-btn"
                    onClick={() => {
                      setCcNumber('1014908123');
                      setBirthDate('1998-05-15');
                      setCapturedImage('https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=300');
                      // Wait a brief animation to represent scanning
                      setScanning(true);
                      setTimeout(() => {
                        setScanning(false);
                        setScanResult({ verified: true, age: 28 });
                      }, 1000);
                    }}
                    className="px-2.5 py-1 bg-emerald-950/20 hover:bg-emerald-900/30 text-emerald-400 border border-emerald-900/30 rounded-sm text-[9px] font-bold uppercase tracking-wider cursor-pointer"
                  >
                    Simular CC Mayor (OK)
                  </button>
                  <button
                    id="simulate-rejected-btn"
                    onClick={() => {
                      setCcNumber('1023456789');
                      setBirthDate('2012-08-20');
                      setCapturedImage('https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=300');
                      setScanning(true);
                      setTimeout(() => {
                        setScanning(false);
                        setScanResult({ verified: false, age: 13, reason: 'Edad insuficiente: Tienes 13 años. El sistema prohíbe el registro de menores de edad.' });
                      }, 1000);
                    }}
                    className="px-2.5 py-1 bg-rose-95/20 hover:bg-rose-900/40 text-rose-400 border border-rose-900/30 rounded-sm text-[9px] font-bold uppercase tracking-wider cursor-pointer"
                  >
                    Simular CC Menor
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'forgot-password' && (
            <motion.div
              key="forgot-password-flow"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-4 font-sans"
            >
              <div>
                <p className="text-[10px] uppercase tracking-[0.2em] text-white/40">RF 4: Restablecer Acceso</p>
                <h2 className="text-2xl font-light tracking-tighter text-white uppercase leading-none mt-1">Recuperar Contraseña</h2>
                <p className="text-[11px] text-white/50 mt-1">
                  Opción de restablecer tu acceso mediante tu Correo o Número Celular.
                </p>
              </div>

              {recoveryError && (
                <div id="recovery-error" className="p-3 bg-rose-95/20 border border-rose-900/30 text-rose-450 rounded-sm flex items-start gap-2 text-xs">
                  <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-rose-500" />
                  <span>{recoveryError}</span>
                </div>
              )}

              {forgotStep === 1 && (
                <form onSubmit={handleRequestRecoveryCode} className="space-y-4">
                  <div>
                    <span className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-2">
                      Método de envío
                    </span>
                    <div className="flex bg-[#0A0A0A] p-1 rounded-sm border border-white/10">
                      <button
                        id="recover-select-email"
                        type="button"
                        onClick={() => {
                          setForgotMethod('email');
                          setForgotValue('');
                        }}
                        className={`flex-1 py-1.5 text-xs font-semibold uppercase tracking-wider rounded-sm transition-all cursor-pointer ${
                          forgotMethod === 'email' ? 'bg-white/5 border border-white/10 text-amber-500 shadow-sm' : 'text-white/60'
                        }`}
                      >
                        Correo
                      </button>
                      <button
                        id="recover-select-phone"
                        type="button"
                        onClick={() => {
                          setForgotMethod('phone');
                          setForgotValue('');
                        }}
                        className={`flex-1 py-1.5 text-xs font-semibold uppercase tracking-wider rounded-sm transition-all cursor-pointer ${
                          forgotMethod === 'phone' ? 'bg-white/5 border border-white/10 text-amber-500 shadow-sm' : 'text-white/60'
                        }`}
                      >
                        Celular
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1.5">
                      {forgotMethod === 'email' ? 'Tu Correo de Cuenta' : 'Número Celular de Cuenta'}
                    </label>
                    <div className="relative">
                      {forgotMethod === 'email' ? (
                        <Mail className="absolute left-3 top-2.5 h-4 w-4 text-white/30" />
                      ) : (
                        <Phone className="absolute left-3 top-2.5 h-4 w-4 text-white/30" />
                      )}
                      <input
                        id="recovery-identifier-input"
                        type={forgotMethod === 'email' ? 'email' : 'tel'}
                        placeholder={forgotMethod === 'email' ? 'ej. carlos@correo.com' : 'ej. 3123456789'}
                        required
                        value={forgotValue}
                        onChange={(e) => setForgotValue(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 text-white pl-10 pr-4 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-500 transition-all font-sans"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2.5 pt-2">
                    <button
                      id="btn-recover-back-login"
                      type="button"
                      onClick={() => {
                        setActiveTab('login');
                        setForgotStep(1);
                        setRecoveryError('');
                      }}
                      className="flex-1 py-2 bg-white/5 text-white/60 hover:text-white border border-white/10 text-xs font-semibold rounded-sm uppercase tracking-wider transition-colors cursor-pointer"
                    >
                      Volver
                    </button>
                    <button
                      id="btn-recover-send"
                      type="submit"
                      className="flex-1 py-2 bg-amber-500 text-black text-xs font-bold rounded-sm hover:bg-[#ff8c38] transition-all uppercase tracking-wider cursor-pointer shadow-sm"
                    >
                      Enviar Código
                    </button>
                  </div>
                </form>
              )}

              {forgotStep === 2 && (
                <form onSubmit={handleVerifyCode} className="space-y-4">
                  <div className="p-3 bg-blue-950/20 border border-blue-900/35 text-blue-400 rounded-sm text-xs flex gap-2">
                    <KeyRound className="h-4 w-4 shrink-0 mt-0.5 text-blue-400" />
                    <div>
                      <p className="font-semibold uppercase tracking-wider text-white">Código Enviado</p>
                      <p className="text-[11px] text-white/60 mt-0.5">
                        Hemos despachado un código de 6 dígitos a tu {forgotMethod === 'email' ? 'correo' : 'móvil'}{' '}
                        <span className="text-white font-mono">{forgotValue}</span>.
                      </p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1.5">
                      Ingresa Código de Verificación
                    </label>
                    <input
                      id="recovery-code-input"
                      type="text"
                      placeholder="XXXXXX"
                      maxLength={6}
                      required
                      value={enteredCode}
                      onChange={(e) => setEnteredCode(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 text-white py-2 text-center text-lg font-bold font-mono tracking-widest rounded-sm focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="flex gap-2.5">
                    <button
                      id="btn-code-back"
                      type="button"
                      onClick={() => setForgotStep(1)}
                      className="flex-1 py-2 bg-white/5 text-white/60 hover:text-white border border-white/10 text-xs font-semibold rounded-sm uppercase tracking-wider cursor-pointer"
                    >
                      Reenviar
                    </button>
                    <button
                      id="btn-code-submit"
                      type="submit"
                      className="flex-1 py-2 bg-amber-500 text-black text-xs font-bold rounded-sm hover:bg-[#ff8c38] transition-all uppercase tracking-wider cursor-pointer shadow-sm"
                    >
                      Validar Código
                    </button>
                  </div>
                </form>
              )}

              {forgotStep === 3 && (
                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div className="p-3 bg-emerald-950/20 border border-emerald-900/30 text-emerald-400 rounded-sm text-xs flex gap-2">
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                    <p>Identidad Verificada. Ingresa tu nueva contraseña para continuar.</p>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                        Nueva Contraseña
                      </label>
                      <input
                        id="new-password-input"
                        type="password"
                        placeholder="Mínimo 4 caracteres"
                        required
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 text-white px-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-400 font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase tracking-[0.2em] text-white/40 mb-1">
                        Confirmar Nueva Contraseña
                      </label>
                      <input
                        id="confirm-new-password-input"
                        type="password"
                        placeholder="Repite la contraseña"
                        required
                        value={confirmNewPassword}
                        onChange={(e) => setConfirmNewPassword(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 text-white px-3 py-2 text-xs rounded-sm focus:outline-none focus:border-amber-400 font-mono"
                      />
                    </div>
                  </div>

                  <button
                    id="btn-reset-password-submit"
                    type="submit"
                    className="w-full py-2.5 bg-amber-500 text-black font-semibold text-xs rounded-sm hover:bg-[#ff8c38] transition-all uppercase tracking-wider cursor-pointer shadow-sm"
                  >
                    Restablecer e Ingresar
                  </button>
                </form>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Developer Help Tip */}
        <div className="mt-6 pt-5 border-t border-white/10 text-center text-[10px] text-white/30 font-mono">
          <span>Usuarios demos en sistema: cocinero_delicia / admin123 </span>
        </div>
      </div>
    </div>
  );
}
